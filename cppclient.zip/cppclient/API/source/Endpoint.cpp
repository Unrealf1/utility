//
// Created by fedor on 8/16/20.
//

#include "Communicator/Endpoint.hpp"

namespace communicator {
    const std::string Endpoint::protocol_address_delimiter = "://";
}